<template>
  <footer class="app-footer">
    <small>電影訂票系統 </small>
  </footer>
</template>

<script setup></script>

<style scoped>
.app-footer {
  padding: 12px 24px;
  border-top: 1px solid #ddd;
  text-align: center;
  font-size: 12px;
  color: #666;
}
</style>
