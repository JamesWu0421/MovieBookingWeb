<template>
  <el-card>
    <h3>電影/影廳管理</h3>
    <p>此頁面為功能佔位，之後可依需求串接 API 與加入表格/表單。</p>
  </el-card>
</template>

<script setup>
</script>
