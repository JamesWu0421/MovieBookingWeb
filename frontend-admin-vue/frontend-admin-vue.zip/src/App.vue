<template>
  <router-view />
</template>

<script setup>
</script>

<style>
body, html, #app { height: 100%; margin: 0; font-family: 'Microsoft JhengHei', 'Segoe UI', Roboto, sans-serif;}
</style>
